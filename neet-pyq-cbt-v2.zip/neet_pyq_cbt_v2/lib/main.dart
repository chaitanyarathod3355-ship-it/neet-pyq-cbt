import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const NeetApp());

class Question {
  final String id, subject, chapter, text, explanation;
  final int year, answer;
  final List<String> options;

  const Question({
    required this.id, required this.year, required this.subject,
    required this.chapter, required this.text, required this.options,
    required this.answer, required this.explanation,
  });

  factory Question.fromJson(Map<String, dynamic> j) => Question(
    id: j['id'], year: j['year'], subject: j['subject'],
    chapter: j['chapter'], text: j['question'],
    options: List<String>.from(j['options']),
    answer: j['answer'], explanation: j['explanation'],
  );
}

class NeetData {
  final List<Question> questions;
  final Map<String, List<String>> chapters;
  const NeetData(this.questions, this.chapters);
}

Future<NeetData> loadData() async {
  final qRaw = await rootBundle.loadString('assets/questions.json');
  final cRaw = await rootBundle.loadString('assets/chapters.json');
  final qJson = jsonDecode(qRaw) as List;
  final cJson = jsonDecode(cRaw) as Map<String, dynamic>;
  return NeetData(
    qJson.map((e) => Question.fromJson(e)).toList(),
    cJson.map((k, v) => MapEntry(k, List<String>.from(v))),
  );
}

class NeetApp extends StatelessWidget {
  const NeetApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'NEET PYQ CBT',
    theme: ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      colorSchemeSeed: Colors.blue,
      scaffoldBackgroundColor: const Color(0xFF090D14),
    ),
    home: const Home(),
  );
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('NEET PYQ CBT')),
    body: FutureBuilder<NeetData>(
      future: loadData(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Choose a subject',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Pick a chapter. Every PYQ mapped to that chapter is automatically included.'),
            const SizedBox(height: 24),
            ...data.chapters.keys.map((s) => Card(
              child: ListTile(
                contentPadding: const EdgeInsets.all(14),
                leading: CircleAvatar(child: Icon(_icon(s))),
                title: Text(s, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                subtitle: Text('${data.chapters[s]!.length} chapters'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => Chapters(data: data, subject: s),
                )),
              ),
            )),
          ],
        );
      },
    ),
  );

  static IconData _icon(String s) {
    if (s == 'Physics') return Icons.bolt;
    if (s == 'Chemistry') return Icons.science;
    if (s == 'Botany') return Icons.eco;
    return Icons.pets;
  }
}

class Chapters extends StatelessWidget {
  final NeetData data;
  final String subject;
  const Chapters({super.key, required this.data, required this.subject});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(subject)),
    body: ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: data.chapters[subject]!.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final chapter = data.chapters[subject]![i];
        final qs = data.questions.where((q) =>
          q.subject == subject && q.chapter == chapter).toList()
          ..sort((a,b) => b.year.compareTo(a.year));

        return Card(
          child: ListTile(
            leading: CircleAvatar(child: Text('${i + 1}')),
            title: Text(chapter, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(qs.isEmpty ? 'No PYQs added yet' : '${qs.length} PYQs • all years'),
            trailing: qs.isEmpty ? const Icon(Icons.lock_outline) : const Icon(Icons.play_arrow),
            onTap: qs.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => Quiz(questions: qs, subject: subject, chapter: chapter),
            )),
          ),
        );
      },
    ),
  );
}

class Quiz extends StatefulWidget {
  final List<Question> questions;
  final String subject, chapter;
  const Quiz({super.key, required this.questions, required this.subject, required this.chapter});
  @override State<Quiz> createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  int index = 0, score = 0;
  int? selected;
  bool answered = false;
  Question get q => widget.questions[index];

  void choose(int i) {
    if (answered) return;
    setState(() {
      selected = i;
      answered = true;
      if (i == q.answer) score++;
    });
  }

  void next() {
    if (!answered) return;
    if (index == widget.questions.length - 1) {
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => Result(score: score, total: widget.questions.length,
          subject: widget.subject, chapter: widget.chapter),
      ));
    } else {
      setState(() { index++; selected = null; answered = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.chapter),
      actions: [Center(child: Padding(
        padding: const EdgeInsets.only(right: 16),
        child: Text('${index + 1}/${widget.questions.length}'),
      ))],
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        LinearProgressIndicator(value: (index + 1) / widget.questions.length),
        const SizedBox(height: 20),
        Text('NEET/AIPMT ${q.year}',
          style: TextStyle(color: Theme.of(context).colorScheme.primary,
            fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text(q.text, style: const TextStyle(fontSize: 20, height: 1.45, fontWeight: FontWeight.w600)),
        const SizedBox(height: 22),
        ...List.generate(4, (i) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => choose(i),
            child: Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: _color(i),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _border(i)),
              ),
              child: Row(children: [
                CircleAvatar(radius: 18, child: Text(String.fromCharCode(65+i))),
                const SizedBox(width: 12),
                Expanded(child: Text(q.options[i], style: const TextStyle(fontSize: 16))),
              ]),
            ),
          ),
        )),
        if (answered) Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(selected == q.answer ? '✓ Correct' : '✕ Wrong',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold,
                  color: selected == q.answer ? Colors.greenAccent : Colors.redAccent)),
              const SizedBox(height: 8),
              Text('Correct answer: ${String.fromCharCode(65+q.answer)}'),
              const SizedBox(height: 8),
              Text(q.explanation),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton(
          onPressed: answered ? next : null,
          child: Text(index == widget.questions.length - 1 ? 'Finish Test' : 'Next Question'),
        ),
      ],
    ),
  );

  Color _color(int i) {
    if (!answered) return const Color(0xFF151D2B);
    if (i == q.answer) return Colors.green.shade800;
    if (i == selected) return Colors.red.shade800;
    return const Color(0xFF151D2B);
  }

  Color _border(int i) {
    if (!answered) return Colors.white10;
    if (i == q.answer || i == selected) return Colors.white54;
    return Colors.white10;
  }
}

class Result extends StatelessWidget {
  final int score, total;
  final String subject, chapter;
  const Result({super.key, required this.score, required this.total,
    required this.subject, required this.chapter});

  @override
  Widget build(BuildContext context) {
    final percent = (score / total * 100).round();
    return Scaffold(
      appBar: AppBar(title: const Text('Result')),
      body: Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.emoji_events, size: 80),
          const SizedBox(height: 18),
          const Text('Test Complete!', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('$subject • $chapter'),
          const SizedBox(height: 24),
          Text('$score / $total', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold)),
          Text('$percent% accuracy'),
          const SizedBox(height: 26),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Back to Chapter')),
          TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
            child: const Text('Home')),
        ]),
      )),
    );
  }
}
