# NEET PYQ CBT v2

The important architecture is now:

Home -> Subject -> Chapter -> ALL questions mapped to that chapter -> CBT

Questions live in `assets/questions.json`.
Chapter names live in `assets/chapters.json`.

To add a PYQ, add one JSON object to questions.json. The app automatically:
- finds its subject
- finds its chapter
- includes it in that chapter's test
- sorts chapter questions by year (newest first)

Example:
{
  "id": "phy_2019_001",
  "year": 2019,
  "subject": "Physics",
  "chapter": "Kinematics",
  "question": "Question text",
  "options": ["A", "B", "C", "D"],
  "answer": 0,
  "explanation": "Explanation"
}

`answer` is 0=A, 1=B, 2=C, 3=D.

Run:
flutter pub get
flutter run

Build:
flutter build apk --release

The included questions are demo data. Use PYQs you are legally permitted to distribute.
